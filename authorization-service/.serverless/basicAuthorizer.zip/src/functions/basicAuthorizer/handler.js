var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/functions/basicAuthorizer/handler.ts
var handler_exports = {};
__export(handler_exports, {
  basicAuthorizer: () => basicAuthorizer
});
module.exports = __toCommonJS(handler_exports);
var crypto = __toESM(require("crypto"));
var basicAuthorizer = (event, context, callback) => {
  console.log(event);
  const authHeader = event.headers.Authorization;
  if (!authHeader) {
    callback(null, getAuthResponse(event, "Deny"));
  }
  try {
    const encodedCreds = authHeader.split(" ")[1];
    const [username, password] = Buffer.from(encodedCreds, "base64").toString().split(":");
    const savedPassword = process.env[username];
    if (!savedPassword || savedPassword !== password) {
      callback(null, getAuthResponse(event, "Deny"));
    }
  } catch (err) {
    console.log(err);
    callback(null, getAuthResponse(event, "Deny"));
  }
  callback(null, getAuthResponse(event, "Allow"));
};
var getAuthResponse = (event, effect) => {
  return {
    principalId: crypto.randomUUID(),
    policyDocument: {
      Version: "2012-10-17",
      Statement: [{
        Action: "execute-api:Invoke",
        Effect: effect,
        Resource: event.methodArn
      }]
    }
  };
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  basicAuthorizer
});
//# sourceMappingURL=handler.js.map
